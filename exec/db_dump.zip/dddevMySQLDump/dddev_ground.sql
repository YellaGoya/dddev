-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 13.124.188.216    Database: dddev
-- ------------------------------------------------------
-- Server version	8.0.35-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ground`
--

DROP TABLE IF EXISTS `ground`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ground` (
  `id` int NOT NULL AUTO_INCREMENT,
  `repository_id` int NOT NULL,
  `profile_id` int DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `focus_time` int DEFAULT '5',
  `active_time` int DEFAULT '3',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `FK_profile_TO_ground_1_idx` (`profile_id`),
  KEY `FK_repository_TO_ground_1_idx` (`repository_id`),
  CONSTRAINT `FK3t9xa7o69v5k3h5lgbl9vn2il` FOREIGN KEY (`repository_id`) REFERENCES `repository` (`id`),
  CONSTRAINT `FK6jpuaeaaoffkcka6qhwtg5kjy` FOREIGN KEY (`profile_id`) REFERENCES `profile` (`id`),
  CONSTRAINT `FK_profile_TO_ground_1` FOREIGN KEY (`profile_id`) REFERENCES `profile` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `FK_repository_TO_ground_1` FOREIGN KEY (`repository_id`) REFERENCES `repository` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ground`
--

LOCK TABLES `ground` WRITE;
/*!40000 ALTER TABLE `ground` DISABLE KEYS */;
INSERT INTO `ground` VALUES (1,4,NULL,'말랑뽀짝콩떡이들',5,3,'2023-11-14 09:35:53'),(51,78,NULL,'log_test',5,3,'2023-11-14 09:42:37'),(52,92,NULL,'-old-yellagoya.github.io',50,3,'2023-11-14 09:53:25'),(53,119,NULL,'webhook-test',5,3,'2023-11-14 10:16:21'),(54,80,NULL,'02_DataBase',5,3,'2023-11-14 17:42:48'),(55,126,NULL,'taxi_project',5,3,'2023-11-15 10:05:08'),(56,123,NULL,'codetree-TILs',5,3,'2023-11-15 16:31:02'),(57,120,NULL,'토이플젝',5,3,'2023-11-15 20:32:24'),(63,175,NULL,'Algorithm',10,6,'2023-11-16 20:53:18'),(64,83,NULL,'05_BackEnd',5,3,'2023-11-16 20:54:15'),(65,176,NULL,'테스트용도',5,3,'2023-11-16 21:08:53'),(66,86,NULL,'gson',5,3,'2023-11-16 21:09:17'),(67,177,NULL,'codetree-TILs',5,3,'2023-11-16 21:34:10'),(68,3,NULL,'Forensics_Visualization',5,3,'2023-11-16 22:13:52'),(69,193,NULL,'dddev',5,3,'2023-11-16 22:48:45');
/*!40000 ALTER TABLE `ground` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-17 10:08:38
