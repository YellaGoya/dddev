-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 13.124.188.216    Database: dddev
-- ------------------------------------------------------
-- Server version	8.0.35-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user_device_token`
--

DROP TABLE IF EXISTS `user_device_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_device_token` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `device_token` varchar(200) NOT NULL,
  KEY `fk_user_device_token_user_idx` (`user_id`),
  CONSTRAINT `fk_user_device_token_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_device_token`
--

LOCK TABLES `user_device_token` WRITE;
/*!40000 ALTER TABLE `user_device_token` DISABLE KEYS */;
INSERT INTO `user_device_token` VALUES (10,'dRT6lb2tM2S4-GgBvilUOb:APA91bEuCyGJrvydEIUy3JH3C66gy3eHf3_2m_YHg2W7AzQP5dzhFV80XaWs6Um-XLzxORQC-hDwxPQevbVuwdLqIBp4xl4NKCI7df5PSo0A6X2odPPDWEuPJvTW_j1Y6AzJY76hnuEx'),(10,'e1qauEo3rrs08xDQir5NN1:APA91bE0ar5bDCYo8YtbOOW8MmOZHoG7paWDmFmYdRz6-rrSKijMyeogtklcnIFSNWpUkphzUpc1Lj_e8IQruoOZTEGugShwVLvBhybC_0e7BxMt2NwAuEDa2axdQqN7Mag17XQDLYKW'),(3,'d9mXlDbAdEzW8m4WC1RDvr:APA91bHWXfTUPJ7y6HsZwlk9bgfpJLL4V23pp27mZqQiBZrCNoAs5TtI00NgqIXv09qa2Hev9-kU2wHkUPQXbHm7iDAlCw32ui0niJ17g4OPYCthxAr-pTFss2JR84wLlyn4CikFvjB4'),(3,'ddym5PVVICOtzyHXDzxELB:APA91bHd6lhm8An8MdNQW_pO5gm_Q90LOUHjfmUzwHZTFUz0RND-YowqJcKuGW8omv2UX_AIJXQQZziVzAfAHm2d5Aa9cBBjsgDx9ODM_iOoc4jRpsyfR1654E-ykKksZpVEcT1HNr1p'),(17,'e1qauEo3rrs08xDQir5NN1:APA91bE0ar5bDCYo8YtbOOW8MmOZHoG7paWDmFmYdRz6-rrSKijMyeogtklcnIFSNWpUkphzUpc1Lj_e8IQruoOZTEGugShwVLvBhybC_0e7BxMt2NwAuEDa2axdQqN7Mag17XQDLYKW'),(17,'elPnJkOXifnVDpQ_xtji-C:APA91bGr69_KQcfHBnHWrDiZyCqJ8-2FmVjiiFRL-GjXLAnKlAiSnzaN3t4K5j4mPoOuN2EFTRpJ_K6HYgfyLLcyi7R8UknKe5tXti82rq6c9uhb3Urw1v_PkIiN-5GhmLZVInnPCgBI');
/*!40000 ALTER TABLE `user_device_token` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-17 10:08:34
