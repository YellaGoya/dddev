-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 13.124.188.216    Database: dddev
-- ------------------------------------------------------
-- Server version	8.0.35-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `repository`
--

DROP TABLE IF EXISTS `repository`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `repository` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `repo_id` int DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `is_private` tinyint(1) DEFAULT NULL,
  `fork` tinyint(1) DEFAULT NULL,
  `default_branch` varchar(100) DEFAULT NULL,
  `is_ground` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_user_TO_repository_1_idx` (`user_id`),
  CONSTRAINT `FK_user_TO_repository_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FKp2u14t90w380jibq93cvr0g9k` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=194 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repository`
--

LOCK TABLES `repository` WRITE;
/*!40000 ALTER TABLE `repository` DISABLE KEYS */;
INSERT INTO `repository` VALUES (1,2,320773719,'covid-19-notification',0,0,'main',0),(2,2,249171677,'File_Analysis_Tool',0,1,'master',0),(3,2,244938004,'Forensics_Visualization',0,0,'master',1),(4,2,244962952,'PintOS',0,0,'master',1),(5,2,332559816,'Program-Machine',0,0,'main',0),(6,2,709131222,'renameTest',1,0,'main',0),(7,2,209236058,'SD_2019_2_team7',0,0,'master',0),(8,2,186917754,'Study-PintOS',0,1,'master',0),(78,9,597670606,'00_Note',1,0,'main',1),(79,9,603605305,'01_Java',0,0,'master',0),(80,9,603604758,'02_DataBase',1,0,'master',1),(81,9,597669998,'03_Algorithm',1,0,'main',0),(82,9,597670139,'04_FrontEnd',1,0,'main',0),(83,9,597670243,'05_BackEnd',1,0,'main',1),(84,9,597670328,'06_Spring',1,0,'main',0),(85,9,597670424,'07_Vue',1,0,'main',0),(86,9,611751091,'gson',0,1,'master',1),(87,9,643748097,'java-springboot',1,0,'main',0),(88,9,493156533,'jeju_price_project',1,0,'main',0),(89,9,715429961,'park_project',1,0,'main',0),(90,9,644137524,'springboot',1,0,'main',0),(91,9,639653336,'vuetify',0,1,'master',0),(92,3,623231224,'-old-yellagoya.github.io',0,0,'main',1),(93,3,655941398,'AlgoSol',0,0,'main',0),(94,3,623225049,'loveSashimi',0,1,'main',0),(95,3,704374786,'NASHDA',0,1,'master',0),(96,3,667092323,'noom',1,0,'main',0),(97,3,459574217,'numpy-into-dataframe',0,0,'main',0),(98,3,681011136,'STVDY',0,0,'master',0),(99,3,691565178,'toy-react-template',0,0,'dev',0),(100,3,655423834,'TripSearchSpring',0,0,'main',0),(101,3,707544314,'web-rtc-test',0,0,'main',0),(102,3,692651274,'yellagoya.github.io',0,0,'dev',0),(103,10,604388572,'academy',1,0,'main',0),(104,10,598352021,'Algorithm',1,0,'main',0),(105,10,638838480,'Enjoy-Trip',1,0,'main',0),(106,10,524286269,'movie_app_2020',0,0,'master',0),(107,10,680960120,'ourola',1,0,'master',0),(108,10,705619711,'spring-cloud-study',0,0,'main',0),(109,10,707182901,'spring-cloud-study-config',0,0,'master',0),(110,10,646498787,'trip-algo',1,0,'master',0),(111,10,646730247,'trip-backend',1,0,'main',0),(112,10,646498427,'trip-db',1,0,'master',0),(113,10,646731331,'trip-frontend',1,0,'master',0),(114,10,646731696,'trip-java',1,0,'master',0),(115,10,646498001,'trip-springboot',1,0,'main',0),(116,10,646497103,'trip-vue',1,0,'main',0),(117,10,645719583,'tripedia',1,0,'main',0),(118,10,702805391,'wanted-pre-onboarding-backend',0,0,'main',0),(119,10,707050040,'webhook-test',0,0,'main',1),(120,10,718019757,'webhook-test-2',0,0,'main',1),(121,13,334838551,'baekbang_admin_fork',1,0,'main',0),(122,13,334058673,'baekbang_react',1,0,'main',0),(123,13,716145086,'codetree-TILs',0,0,'main',1),(124,13,387308863,'forCompany',1,0,'main',0),(125,13,159942052,'sys_project',0,0,'master',0),(126,13,155197695,'taxi_project',0,0,'master',1),(127,13,363074864,'WING-API',1,0,'main',0),(128,13,356192079,'wing_monitoring_react_pratice',1,0,'main',0),(129,13,377771209,'WING_monitoring_system',1,0,'main',0),(174,16,662011351,'Algo',1,0,'main',1),(175,16,487779945,'Algorithm',0,0,'master',1),(176,16,619060390,'boostCourse',0,0,'main',1),(177,16,716816948,'codetree-TILs',0,0,'main',1),(178,16,715453940,'CS-study',1,0,'master',0),(179,16,691912943,'java-springboot',1,0,'main',0),(180,16,554027459,'MLproject',0,0,'master',0),(181,16,409216611,'open-source-software',0,0,'master',0),(182,16,691910768,'OpenBankApi',1,0,'main',0),(183,16,677033352,'project-board',0,0,'main',0),(184,16,635362444,'readme-template',0,1,'master',0),(185,16,416179389,'self_care_adhd',0,0,'main',0),(186,16,711162449,'spring-cloud-config',1,0,'main',0),(187,16,674900863,'Spring_Jpa_init',1,0,'main',0),(188,16,681084378,'Take_A_Bus',0,0,'master',0),(189,16,704936940,'wanted-pre-onboarding-backend',0,0,'main',0),(190,16,679023853,'wanted-pre-onboarding-backend2',1,0,'main',0),(191,16,687411776,'wanted-preonboarding-challenge-backend-13',0,1,'master',0),(192,16,409194922,'Yeon-seok',0,0,'main',0),(193,17,717713509,'dddev',0,0,'main',1);
/*!40000 ALTER TABLE `repository` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-17 10:08:37
