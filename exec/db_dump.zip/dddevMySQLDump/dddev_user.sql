-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 13.124.188.216    Database: dddev
-- ------------------------------------------------------
-- Server version	8.0.35-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `profile_id` int DEFAULT NULL,
  `last_ground_id` int DEFAULT NULL,
  `github_id` int DEFAULT NULL,
  `nickname` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `github_name` varchar(50) DEFAULT NULL,
  `status_msg` varchar(100) DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `valid` tinyint(1) DEFAULT NULL,
  `personal_access_token` varchar(500) DEFAULT NULL,
  `device_token` varchar(200) DEFAULT NULL,
  `role` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_profile_TO_user_1_idx` (`profile_id`),
  CONSTRAINT `FK9r6n2wdr6ra7wbt96fyd98vks` FOREIGN KEY (`profile_id`) REFERENCES `profile` (`id`),
  CONSTRAINT `FK_profile_TO_user_1` FOREIGN KEY (`profile_id`) REFERENCES `profile` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,NULL,NULL,NULL,'ADMIN',NULL,'ADMIN',NULL,'2023-11-14 00:31:42',NULL,NULL,NULL,'ADMIN'),(2,NULL,1,33944540,'kyungsook','lovablekks@naver.com','kyungsook','집에 가고 싶ㅜ다','2023-11-14 09:26:29',1,'sD1dGNldGSZJSefCoKzEl0vkxT5Afr1/uD428keHi8AGT86nl1bWsW8au0Fz20Us',NULL,'USER'),(3,23,69,83230053,'힝매썅매먕묘묘먀야얌','he2kape@gmail.com','YellaGoya',NULL,'2023-11-14 09:27:49',1,'dPWFmYH/gtlcFn9tT6AkviStrjZvABiPHQuSXJevg3xePSiWRnGu//n9Zy7JUYFm',NULL,'USER'),(9,24,69,93653248,'SHyeondibi','kshv02@gmail.com','SHyeondibi',NULL,'2023-11-14 09:39:18',1,'vxOV3aiEUU8IfwQinknHCIv9LMIY2yJGVZZ0gXGakE3SZ1CZmmLYEilVQNM9sVAY',NULL,'USER'),(10,NULL,69,111165249,'gayun0303','gayun0303@gmail.com','gayun0303',NULL,'2023-11-14 09:54:48',1,'6YMmcrQDGeGAYgvHIKPfqW0FWnH4A25cjeTFxjdhA8kawrX/EMp5vm1x61aLcMML',NULL,'USER'),(13,NULL,69,44544326,'Dreamleaf','twnkjsfagnji@gmail.com','Dream-leaf',NULL,'2023-11-14 17:52:34',1,'o7iInkzFsoJKti1LnkebH5ghXyz1LQCmYrKi3USvB18tNFQxbExdYgLLFdfGwPsb',NULL,'USER'),(16,26,65,56334468,'문재인','abcd9351@naver.com','Yeon-seok','삭제','2023-11-16 20:43:29',1,'iN2zddFKZ6o/GP1GvN78SyOHaO1cUaRbEgQFHFBU2PA2r9qopp+O1V9JOIyfhLbU',NULL,'USER'),(17,NULL,69,150590425,'back5front1','ssafydddev@gmail.com','back5front1',NULL,'2023-11-16 22:45:08',1,'VZgwViL6mC19MpJUTyaogFzR5hJ3x176xXG+Kt9g+c8Gq9U5RgqopjQYwG8v2yiN',NULL,'USER'),(18,NULL,NULL,134939365,'devdibi',NULL,'devdibi',NULL,'2023-11-17 09:12:09',1,NULL,NULL,'GUEST');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-17 10:08:35
